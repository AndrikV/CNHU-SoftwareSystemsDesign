const classNames = {
  TODO_ITEM: 'todo-container',
  TODO_CHECKBOX: 'todo-checkbox',
  TODO_TEXT: 'todo-text',
  TODO_DELETE: 'todo-delete',
}

const list = document.getElementById('todo-list')
const itemCountSpan = document.getElementById('item-count')
const uncheckedCountSpan = document.getElementById('unchecked-count')

function newTodo() {
  let todoItems = list.getElementsByClassName(classNames.TODO_ITEM);
  let todoItemsData = [];
  for (let i = 0; i < todoItems.length; i++) {
    todoItemsData.push(
      {
        text: todoItems[i].getElementsByTagName("textarea")[0].value,
        checkbox: todoItems[i].getElementsByTagName("input")[0].checked
      }
    );
  }

  list.innerHTML = ` 
<div class="${classNames.TODO_ITEM}">
  <textarea class="${classNames.TODO_TEXT}" placeholder="Your TODO"></textarea>
  <input type="checkbox" class="${classNames.TODO_CHECKBOX}" onClick="checkedToggle(event)">
  <button class="todo-delete" onclick="deleteTodo(event)">x</button>
</div>`;
  for (let i = 0; i < todoItemsData.length; i++) {
    let item = todoItemsData[i];
    let checked = item.checkbox ? "checked" : "";
    list.innerHTML += ` 
<div class="${classNames.TODO_ITEM}">
  <textarea class="${classNames.TODO_TEXT}" placeholder="Your TODO">${item.text}</textarea>
  <input type="checkbox" class="${classNames.TODO_CHECKBOX}" ${checked} onClick="checkedToggle(event)">
  <button class="todo-delete" onclick="deleteTodo(event)">x</button>
</div>`;
  }

  itemCountSpan.innerHTML = Number(itemCountSpan.innerHTML) + 1;
  uncheckedCountSpan.innerHTML = Number(uncheckedCountSpan.innerHTML) + 1;
}

function checkedToggle(event) {
  if (event.target.checked)
    uncheckedCountSpan.innerHTML = Number(uncheckedCountSpan.innerHTML) - 1;
  else
    uncheckedCountSpan.innerHTML = Number(uncheckedCountSpan.innerHTML) + 1;
}

function deleteTodo(event) {
  let checkbox = event.target.parentElement.getElementsByTagName("input")[0];
  if (!checkbox.checked)
    uncheckedCountSpan.innerHTML = Number(uncheckedCountSpan.innerHTML) - 1;
  itemCountSpan.innerHTML = Number(itemCountSpan.innerHTML) - 1;
  
  const todoItems = list.getElementsByClassName(classNames.TODO_ITEM);
  let todoItemsData = [];
  let iToDelete = 0;
  for (let i = 0; i < todoItems.length; i++) {
    todoItemsData.push(
      {
        text: todoItems[i].getElementsByTagName("textarea")[0].value,
        checkbox: todoItems[i].getElementsByTagName("input")[0].checked
      }
    );

    if (todoItems[i] == event.target.parentElement)
      iToDelete = i;
  }

  list.innerHTML = ''
  for (let i = 0; i < todoItemsData.length; i++) {
    if (i == iToDelete)
      continue;

    let text = todoItemsData[i].text;
    let checked = todoItemsData[i].checkbox ? "checked" : "";
    list.innerHTML += ` 
<div class="${classNames.TODO_ITEM}">
  <textarea class="${classNames.TODO_TEXT}" placeholder="Your TODO">${text}</textarea>
  <input type="checkbox" class="${classNames.TODO_CHECKBOX}" ${checked} onClick="checkedToggle(event)">
  <button class="todo-delete" onclick="deleteTodo(event)">x</button>
</div>`;
  }
}